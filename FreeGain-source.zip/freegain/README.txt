FREEGAIN - SETUP (on a computer)

1. Install Android Studio (developer.android.com/studio).
2. New Project > "Empty Views Activity". Name: FreeGain.
   Package name: com.freegain.app   Language: Kotlin   Min SDK: API 26.
3. Wait for Gradle to finish syncing.
4. In the project, copy files from this zip:
   - java/*.kt  -> app/src/main/java/com/freegain/app/   (replace MainActivity.kt)
   - res/xml/guard_config.xml -> app/src/main/res/xml/   (create the xml folder)
   - res/values/guard_strings.xml -> app/src/main/res/values/
   - AndroidManifest.xml -> replaces app/src/main/AndroidManifest.xml
5. Delete app/src/main/res/layout/activity_main.xml (not used).
6. Phone: Settings > About phone > tap Build number 7 times, then enable
   Developer options > USB debugging. Plug in the phone, press the green Run button.

FIRST RUN ON PHONE
- Tap "Allow Usage Access" and enable FreeGain.
- Tap "Turn on FreeGain Guard" and enable it in Accessibility.
  If it is greyed out: Settings > Apps > FreeGain > top-right menu (3 dots)
  > "Allow restricted settings", then try again.
- Turn off battery optimization for FreeGain so it is not killed.

IF REELS/SHORTS BLOCKING STOPS WORKING
Instagram/YouTube change their internal view ids in updates. Update the
shortsIds list in GuardService.kt. Find new ids with Android Studio's
Tools > Layout Inspector while Reels/Shorts is open.
