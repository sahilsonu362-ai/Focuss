package com.freegain.app

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sv = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 80, 40, 60)
        }
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun guardOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        return s?.contains(packageName) == true
    }

    private fun text(t: String, size: Float = 16f, bold: Boolean = false) {
        root.addView(TextView(this).apply {
            text = t; textSize = size
            setPadding(0, 24, 0, 8)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
    }

    private fun button(t: String, onClick: () -> Unit) {
        root.addView(Button(this).apply { text = t; setOnClickListener { onClick() } })
    }

    private fun render() {
        root.removeAllViews()
        val sp = Prefs.sp(this)
        text("FreeGain", 28f, true)

        // Permissions
        if (!Usage.hasAccess(this)) button("Step 1: Allow Usage Access") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        if (!guardOn()) button("Step 2: Turn on FreeGain Guard (Accessibility)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // Reels / Shorts switch
        root.addView(Switch(this).apply {
            text = "Block Reels & Shorts"
            isChecked = sp.getBoolean("block_shorts", true)
            setPadding(0, 30, 0, 30)
            setOnCheckedChangeListener { _, c -> sp.edit().putBoolean("block_shorts", c).apply() }
        })

        // Focus mode
        text("Focus mode", 20f, true)
        val left = sp.getLong("focus_until", 0) - System.currentTimeMillis()
        if (left > 0) {
            text("Active: ${left / 60000 + 1} min left. Only phone, settings and home are allowed.")
        } else {
            val et = EditText(this).apply {
                hint = "Minutes (e.g. 25)"
                inputType = InputType.TYPE_CLASS_NUMBER
            }
            root.addView(et)
            button("Start focus") {
                val m = et.text.toString().toIntOrNull() ?: 0
                if (m > 0) {
                    sp.edit().putLong("focus_until", System.currentTimeMillis() + m * 60_000L).apply()
                    render()
                }
            }
        }

        // Screen time list
        text("Today's screen time (tap an app to set a daily limit)", 18f, true)
        if (!Usage.hasAccess(this)) {
            text("Allow Usage Access to see this.")
            return
        }
        val pm = packageManager
        Usage.todayMs(this)
            .filter { it.value > 60_000 && it.key != packageName && pm.getLaunchIntentForPackage(it.key) != null }
            .entries.sortedByDescending { it.value }.take(25)
            .forEach { (pkg, ms) ->
                val name = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
                val mins = ms / 60000
                val limit = sp.getInt("limit_$pkg", 0)
                val lim = if (limit > 0) "   (limit ${limit}m)" else ""
                root.addView(TextView(this).apply {
                    text = "$name: ${mins / 60}h ${mins % 60}m$lim"
                    textSize = 16f
                    setPadding(0, 22, 0, 22)
                    setOnClickListener { askLimit(pkg, name) }
                })
            }
    }

    private fun askLimit(pkg: String, name: String) {
        val et = EditText(this).apply {
            hint = "Minutes per day"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        AlertDialog.Builder(this)
            .setTitle("Daily limit for $name")
            .setView(et)
            .setPositiveButton("Set") { _, _ ->
                Prefs.sp(this).edit().putInt("limit_$pkg", et.text.toString().toIntOrNull() ?: 0).apply()
                render()
            }
            .setNeutralButton("Remove limit") { _, _ ->
                Prefs.sp(this).edit().remove("limit_$pkg").apply(); render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
