package com.freegain.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class GuardService : AccessibilityService() {

    private var lastKick = 0L
    private var lastCheck = 0L
    private var launcherPkg = ""
    private var dialerPkg = ""

    // View-id pieces that identify the full-screen Reels / Shorts players.
    // These can change when Instagram/YouTube update (see README).
    private val shortsIds = mapOf(
        "com.instagram.android" to listOf("clips_viewer", "clips_video_container"),
        "com.google.android.youtube" to listOf("reel_recycler", "reel_player_page")
    )

    override fun onServiceConnected() {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        launcherPkg = packageManager.resolveActivity(home, 0)?.activityInfo?.packageName ?: ""
        val dial = Intent(Intent.ACTION_DIAL)
        dialerPkg = packageManager.resolveActivity(dial, 0)?.activityInfo?.packageName ?: ""
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val sp = Prefs.sp(this)
        val now = System.currentTimeMillis()

        // 1) Focus mode + daily limits (checked at most every 3 seconds)
        if (now - lastCheck > 3000) {
            lastCheck = now
            val focusUntil = sp.getLong("focus_until", 0)
            if (now < focusUntil && !isAllowed(pkg)) {
                kick("Focus mode is on"); return
            }
            val limitMin = sp.getInt("limit_$pkg", 0)
            if (limitMin > 0 && Usage.hasAccess(this)) {
                val used = Usage.todayMs(this)[pkg] ?: 0L
                if (used >= limitMin * 60_000L) {
                    kick("Daily limit reached"); return
                }
            }
        }

        // 2) Reels / Shorts blocking
        if (sp.getBoolean("block_shorts", true) && shortsIds.containsKey(pkg)) {
            val root = rootInActiveWindow ?: return
            if (hasShorts(root, shortsIds[pkg]!!, 0)) {
                if (now - lastKick > 1000) {
                    lastKick = now
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    Toast.makeText(this, "Short videos blocked", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun isAllowed(pkg: String): Boolean {
        return pkg == launcherPkg || pkg == dialerPkg ||
            pkg.contains("systemui") || pkg.contains("inputmethod") ||
            pkg.contains("keyboard") || pkg == "com.android.settings" ||
            pkg == "com.android.phone" || pkg == "com.google.android.dialer"
    }

    private fun kick(msg: String) {
        val now = System.currentTimeMillis()
        if (now - lastKick < 1000) return
        lastKick = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun hasShorts(node: AccessibilityNodeInfo?, ids: List<String>, depth: Int): Boolean {
        if (node == null || depth > 25) return false
        val id = node.viewIdResourceName
        if (id != null && node.isVisibleToUser && ids.any { id.contains(it) }) return true
        for (i in 0 until node.childCount) {
            if (hasShorts(node.getChild(i), ids, depth + 1)) return true
        }
        return false
    }
}
